from setuptools import setup
import platform

package_dir = {'blueprint-one': 'blueprint-one'}

setup(
    name="blueprint-one",
    version="1.0.0",
    description="The baremetal example of the NEORV32 RISC-V Processor on Terrasic DE2-115 board",
    package_dir=package_dir,
    packages=['blueprint-one'],
    include_package_data=True,
    author="SoC.One Inc.",
    url="http://xplor.design",
    author_email="info@soc.one",
    platforms=["Windows", "Linux"],
    long_description="The baremetal example of the NEORV32 RISC-V Processor on Terrasic DE2-115 board",
    license="Free",
    install_requires=[
        # Some dependencies here
    ],
    classifiers=[
        'Hardware'
    ]
)
