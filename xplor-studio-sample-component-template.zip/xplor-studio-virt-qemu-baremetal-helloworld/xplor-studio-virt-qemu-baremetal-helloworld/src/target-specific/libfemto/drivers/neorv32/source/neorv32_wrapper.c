#include <wrapper_platform.h>
#include <neorv32.h>

/**********************************************************************//**
 * @name User configuration
 **************************************************************************/
/**@{*/
/** UART BAUD rate */
#define BAUD_RATE 19200
/**@}*/


//#define printf(...) neorv32_uart0_printf(__VA_ARGS__)

void init_neorv32(){
	  // capture all exceptions and give debug info via UART
	  // this is not required, but keeps us safe
	  neorv32_rte_setup();

	  // init UART at default baud rate, no parity bits, ho hw flow control
	  neorv32_uart0_setup(BAUD_RATE, PARITY_NONE, FLOW_CONTROL_NONE);

	  // check available hardware extensions and compare with compiler flags
	  neorv32_rte_check_isa(0); // silent = 0 -> show message if isa mismatch

	  // print project logo via UART
	  neorv32_rte_print_logo();
}
