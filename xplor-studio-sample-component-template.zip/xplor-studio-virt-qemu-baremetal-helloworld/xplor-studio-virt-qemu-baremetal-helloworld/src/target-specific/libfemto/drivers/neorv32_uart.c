// See LICENSE for license details.

#include "femto.h"
#include "neorv32/include/neorv32.h"

#define BAUD_RATE 19200
static volatile int *uart;
// LAPD: Call Neorv api
static void neorv32_uart_init()
{
	  // capture all exceptions and give debug info via UART
	  // this is not required, but keeps us safe
	  neorv32_rte_setup();

	  // init UART at default baud rate, no parity bits, ho hw flow control
	  neorv32_uart0_setup(BAUD_RATE, PARITY_NONE, FLOW_CONTROL_NONE);

	  // check available hardware extensions and compare with compiler flags
	  neorv32_rte_check_isa(0); // silent = 0 -> show message if isa mismatch

}

// Call neorv32 api
static int neorv32_uart_getchar()
{
    return neorv32_uart0_getc();
}

static int neorv32_uart_putchar(int ch)
{
    neorv32_uart0_putc((char) ch);
}

// Declare console_neorv32_uart to be used in env/neorv32/setup.c
//
const console_device_t console_neorv32_uart = {
    neorv32_uart_init,
    neorv32_uart_getchar,
    neorv32_uart_putchar
};
