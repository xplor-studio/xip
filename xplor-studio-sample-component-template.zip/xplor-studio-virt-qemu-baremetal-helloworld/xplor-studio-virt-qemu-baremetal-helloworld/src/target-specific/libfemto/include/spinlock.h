// See LICENSE for license details.
#pragma once

#ifdef __riscv
#include <arch/riscv/spinlock.h>
#endif
