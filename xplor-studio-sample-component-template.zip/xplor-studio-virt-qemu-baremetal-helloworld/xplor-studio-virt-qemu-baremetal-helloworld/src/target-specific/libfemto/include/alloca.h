#pragma once

#define alloca(size) __builtin_alloca (size)
