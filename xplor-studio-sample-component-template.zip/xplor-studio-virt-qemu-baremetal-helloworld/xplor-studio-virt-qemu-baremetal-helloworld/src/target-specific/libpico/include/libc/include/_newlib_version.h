/* Copyright (c) 2016 Jeff Johnston  <jjohnstn@redhat.com> */
/* dummy file for external tools to use.  Real file is created by
   newlib configuration. */
