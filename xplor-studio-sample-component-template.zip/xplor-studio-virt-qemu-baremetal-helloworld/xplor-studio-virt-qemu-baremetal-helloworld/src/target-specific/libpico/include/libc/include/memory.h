/* Copyright (c) 2016 Sebastian Huber <sebastian.huber@embedded-brains.de> */
#ifndef _MEMORY_H
#define	_MEMORY_H
#include <string.h>
#endif /* !_MEMORY_H */
