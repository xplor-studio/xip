#include <wrapper_platform.h>

void init()
{
#ifdef TARGET_NEORV32
	init_neorv32();
#else
	// Do nothing
#endif
}

int print_num(int num)
{
#ifdef TARGET_OPENMCU
	dbg_hex8(num);
	dbg_str("\n");
#else
	printf("%d\n", num);
#endif
	return 0;
}

int print_str(const char* str)
{
#ifdef TARGET_OPENMCU
	dbg_str(str);
#elif defined(TARGET_CODASIP) || defined(TARGET_ANDES)
	// Do nothing
#else
	printf(str);
#endif
	return 0;
}

void cleanup()
{
#ifdef TARGET_OPENMCU
	boot();
#endif
}
