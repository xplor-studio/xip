#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#ifdef TARGET_OPENMCU
#include "dbg.h"
int boot();
#endif

#ifdef TARGET_NEORV32
void init_neorv32();
#endif

void init();
int print_str(const char* str);
int print_num(int num);
void cleanup();

#ifdef __cplusplus
}
#endif
