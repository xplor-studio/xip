/*
 ============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : !!!Hello RISC-V World!!!
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wrapper_platform.h>

int main(void) {
	int count = 0;

	print_str("Hello world!\n");

	print_str("Start counting...\n");

	for (; count < 10; count++) {
		print_num(count);
	}
	print_str("Bye!\n");

	cleanup();

	return 0;
}
