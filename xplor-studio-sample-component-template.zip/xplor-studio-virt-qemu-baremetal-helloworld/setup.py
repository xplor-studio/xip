from setuptools import setup
import platform

package_dir = {'xplor-studio-virt-qemu-baremetal-helloworld': 'xplor-studio-virt-qemu-baremetal-helloworld'}

setup(
    name="xplor-studio-virt-qemu-baremetal-helloworld",
    version="1.0.0",
    description="Hello World Baremetal Project for XploR Studio",
    package_dir=package_dir,
    packages=['xplor-studio-virt-qemu-baremetal-helloworld'],
    include_package_data=True,
    author="SoC.One Inc.",
    url="https://xplor.design",
    author_email="info@soc.one",
    platforms=["Windows", "Linux"],
    long_description="Hello World Baremetal Project for XploR Studio",
    license="Free",
    install_requires=[
        'xplor-studio-elf'
    ],
    classifiers=[
        'Project',
        'XploR Studio',
    ]
)
