from setuptools import setup
import platform

if platform.system() == 'Windows':
    package_dir = {'component-two': 'component-two/win32.x86_64'}
else:
    package_dir = {'component-two': 'component-two/linux.x86_64'}

setup(
    name="component-two",
    version="1.0.0",
    description="RISC-V Embedded Toolchain",
    package_dir=package_dir,
    packages=['component-two'],
    include_package_data=True,
    author="SoC.One Inc.",
    url="http://xplor.design",
    author_email="info@soc.one",
    platforms=["Windows", "Linux"],
    long_description="XploR Embedded Toolchain for RISC-V (supported both 32 and 64-bit)",
    license="Free",
    classifiers=[
        'Software'
    ]
)
