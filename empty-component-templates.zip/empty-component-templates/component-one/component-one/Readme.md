# The Baremetal application with Neorv32 IP core on Terrasic DE2-115 board
## Prerequisites

- [**Quartus Programmer**](https://www.intel.com/content/www/us/en/collections/products/fpga/software/downloads.html)
- **bitstream-de2115-neorv32** component
- **riscv-xplor-elf** component

## Set up the environment

### 1 - TFTP Server

#### TFTP Server on Linux

TFTP server contains some necessary files for booting Linux. To create TFTP server via docker:

``` sh
$ cd tftpboot/
$ docker rm -f tftpboot
$ docker run -itd --name=tftpboot --net=host  --restart=always -v $PWD:/var/tftpboot  pghalliday/tftp
```

#### TFTP Server on Windows

**Prerequisites**:

- **Administrator permission**
- **SolarWinds TFTP Server**: To set up a TFTP server, users will have to download the TFTP Server utility such as SolarWinds can be downloaded from https://www.solarwinds.com/free-tools/free-tftp-server. Once the .zip file is downloaded, extract it and go through the straightforward installation.
- **Firewall setup**: To allow remote access to the TFTP server, users need to open the firewall for TFTP service.

**Start the TFTP Server**

Run the **SolarWinds TFTP Server** utility by going to the **Start Menu** and searching for **TFTP Server**.
Once it loads up, copy the **boot.json** and **demo.bin** to **C:\TFTP-Root** folder.


### 2 - Connect the serial port

The bitstream is built based on the [LiteX framework](https://github.com/enjoy-digital/litex) so we will using `litex_term` to connect the serial port.

``` sh 
$ litex_term /dev/ttyUSB0 --speed 19200
```
### 3 - Flashing the DE2-115 board

Before flashing, you should detect the index of USB-Blaster via `jtagconfig`:

```
$ jtagconfig
1) USB-Blaster [1-9.1]
  020F70DD   10CL120(Y|Z)/EP3C120/..
```

> In this case, the index of USB-Blaster is 1.

Flashing command:

``` sh
quartus_pgm -c 1 -m JTAG -o p\;$XPLOR_HOME/components/bitstream-de2115-neorv32/de2-115_neorv32.sof@1
```

## Build, run, debug the Baremetal application

> Make sure to source the environment-setup.sh/environment-setup.bat file first (at `$XPLOR_HOME/components`/)

### 1 - Build the "Hello world" application

``` sh
$ cd $XPLOR_HOME/components/baremetal-neorv32-de2115/litex-riscv-baremetal
$ source ./exp.sh
$ make clean
$ make
```

### 2 - Run the application without debugging

Copy `boot.json` and `demo.bin` (in *litex-riscv-baremetal* folder) to your tftp folder
- Restart tftp server
- In `litex_term` set IP address of local (board) and remote (tftp server) then run `netboot`
```sh
eth_local_ip 192.168.1.50
eth_remote_ip 192.168.1.100
netboot
```

By the default, the host PC and the board has IP addresses is `192.168.1.100` and `192.168.1.50` respectively. If the IP address of the host PC is different from the default, the booting process will not be complete. Then we need to re-assign IP address and re-boot by command `netboot`. By this way, the application can be run:

 ``` sh
Hello 0
Hello 1
Hello 2
Hello 3
Hello 4
Hello 5
Hello 6
Hello 7
Hello 8
Hello 9
Goodbye!
```

### 3 - Debug the application

On the host terminal, run the `openocd` command with the configuration file. 

``` sh
$ cd $XPLOR_HOME/components/baremetal-neorv32-de2115/openocd_cfg/
$ openocd -f de2_115.cfg
```

On the host terminal, run `riscv-xplor-elf-gdb` command with the executable file, then debug with gdb console.

``` sh
$ cd $XPLOR_HOME/components/baremetal-neorv32-de2115/openocd_cfg/
$ riscv-xplor-elf-gdb -ex 'target remote localhost:3333' demo.elf
$ (gdb) b main
$ (gdb) c
$ (gdb) n
$ ...

```

> For debugging with GUI, please install `xplor-studio-ide` component then install `xplor-studio-elf` component
